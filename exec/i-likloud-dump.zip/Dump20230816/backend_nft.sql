-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i9d101.p.ssafy.io    Database: backend
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nft`
--

DROP TABLE IF EXISTS `nft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nft` (
  `nft_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `content` varchar(255) NOT NULL,
  `contract` varchar(255) NOT NULL,
  `nft_image_url` varchar(255) NOT NULL,
  `nft_metadata` text NOT NULL,
  `title` varchar(255) NOT NULL,
  `token_id` varchar(255) NOT NULL,
  `drawing_id` bigint DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  `transfer_id` bigint DEFAULT NULL,
  PRIMARY KEY (`nft_id`),
  KEY `FKmesoqt9iuxbhs7ldgvu8asul9` (`drawing_id`),
  KEY `FK4k2026y0y087aeo0upalqivtk` (`member_id`),
  KEY `FKlred4cdambqpdoqt8h3n5dhpn` (`transfer_id`),
  CONSTRAINT `FK4k2026y0y087aeo0upalqivtk` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`),
  CONSTRAINT `FKlred4cdambqpdoqt8h3n5dhpn` FOREIGN KEY (`transfer_id`) REFERENCES `nft_transfer` (`transfer_id`),
  CONSTRAINT `FKmesoqt9iuxbhs7ldgvu8asul9` FOREIGN KEY (`drawing_id`) REFERENCES `drawing` (`drawing_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nft`
--

LOCK TABLES `nft` WRITE;
/*!40000 ALTER TABLE `nft` DISABLE KEYS */;
INSERT INTO `nft` VALUES (1,'2023-08-13 11:36:03.377372','2023-08-13 11:36:03.377372','못생긴 돼지 ','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/e279d4f8-a1a1-443b-8ecc-bc44e106ef74230813_111522.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x785850067434988c.json','꿀꿀이','0x785850067434988c',3,5,NULL),(2,'2023-08-13 11:36:08.311992','2023-08-13 11:36:08.311992','뿔이 있고 불을 뿜는다','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/099b95ca-33e6-45fd-91ed-2928dce8fcba230813_111559.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x4e938f8925f4d7fd.json','불 뿜는 용','0x4e938f8925f4d7fd',6,2,NULL),(3,'2023-08-13 11:37:38.904922','2023-08-13 11:37:38.904922','♡♡','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/ecc5e09b-4db9-4961-91f0-e19e7a5a8ffe230813_112318.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x449f6e7f52bd63df.json','핱하트무늬동물','0x449f6e7f52bd63df',8,1,NULL),(4,'2023-08-13 11:38:27.571650','2023-08-13 11:38:27.571650','토코','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/d8ca5c19-fef3-4767-a926-644554f72bc9230813_112310.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x4c7cce8d534e535a.json','얼룩강아지','0x4c7cce8d534e535a',7,8,NULL),(5,'2023-08-13 11:38:58.861649','2023-08-13 11:38:58.861649','악어떼','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/5c092b45-8eae-4cc3-8bc1-e10c9e8ac82f230813_113152.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x567904b45fee898e.json','악어','0x567904b45fee898e',9,6,NULL),(6,'2023-08-13 11:39:53.319063','2023-08-13 11:39:53.319063','애벌래','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/dc5d190d-bb49-497d-85f9-11770f95fb68230813_111230.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x502c6db2ceddbc02.json','애벌래','0x502c6db2ceddbc02',1,1,NULL),(7,'2023-08-13 11:42:02.784837','2023-08-13 11:55:40.721560','강아지','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/44bc92ee-0ea5-420e-b616-68790497d860230813_114037.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x64c305b3ea18ad8d.json','강아지','0x64c305b3ea18ad8d',10,1,NULL),(8,'2023-08-13 11:43:45.046554','2023-08-13 11:43:45.046554','못생긴 돼지','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/61281c33-e6cf-4ec4-a100-60f55480434a230813_111522.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x5be20f7a3e13bf5b.json','꿀꿀이','0x5be20f7a3e13bf5b',4,5,NULL),(9,'2023-08-13 11:43:51.775905','2023-08-13 11:43:51.775905','못생긴 돼지 ','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/7bfed640-4039-4c5f-ab55-461b67d6990d230813_111522.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x4284a3e76f516aaa.json','꿀꿀이','0x4284a3e76f516aaa',2,5,NULL),(10,'2023-08-13 11:44:02.761459','2023-08-13 11:44:02.761459','못생긴 돼지','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/bc89dfbb-aff5-485d-ba0b-cff38a71b8d9230813_111522.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x6e0c2b4c1bdff409.json','꿀꿀이','0x6e0c2b4c1bdff409',5,5,NULL),(12,'2023-08-13 11:56:36.562284','2023-08-13 11:56:36.562284','ㄹㅇㄹㄹㄹㄹ, \nㅣㅡ\n','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/2b26d720-7bdc-4297-a7ce-f754d79781bb230813_114742.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x73195e7f015e70bf.json','오옹 ','0x73195e7f015e70bf',11,5,NULL),(15,'2023-08-14 12:47:11.429846','2023-08-14 15:37:56.779143','cloud','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/52b64f60-78bc-40fa-b2d1-b46d0ec263ff230813_133904.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x6f4dce8f429742d0.json','long','0x6f4dce8f429742d0',14,NULL,NULL),(16,'2023-08-15 16:51:24.435810','2023-08-15 16:51:24.435810','짹짹','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/cc7dcdff-800e-43ab-85a4-c79a7251d391230815_153446.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x6f188fb1fd02abba.json','병아리','0x6f188fb1fd02abba',29,4,NULL),(17,'2023-08-15 16:52:20.126218','2023-08-15 16:53:09.443667','새','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/0e06bedd-279d-4611-8afd-5122a1c30985230815_165159.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x69e0129e2d01cd4d.json','새','0x69e0129e2d01cd4d',30,NULL,NULL),(18,'2023-08-16 13:53:06.696039','2023-08-16 13:53:06.696039','제발~~~!','unijoa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/43b0aaea-4e46-4259-b14e-99369a17c391230816_045252.jpg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/nft-metadata/0x51ccfe9b5028dacc.json','출시하자	','0x51ccfe9b5028dacc',31,3,NULL);
/*!40000 ALTER TABLE `nft` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-16 17:14:32
