-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i9d101.p.ssafy.io    Database: backend
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `drawing`
--

DROP TABLE IF EXISTS `drawing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drawing` (
  `drawing_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `artist` varchar(20) NOT NULL,
  `content` varchar(300) DEFAULT NULL,
  `image_url` varchar(255) NOT NULL,
  `likes_count` int NOT NULL DEFAULT '0',
  `nft_yn` bit(1) NOT NULL,
  `title` varchar(50) NOT NULL,
  `view_count` int NOT NULL DEFAULT '0',
  `drawing_file_id` bigint DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  `nft_id` bigint DEFAULT NULL,
  `photo_id` bigint DEFAULT NULL,
  PRIMARY KEY (`drawing_id`),
  KEY `FKjdxqaj1hxder72fm9qjn8lyht` (`drawing_file_id`),
  KEY `FKn02g518xhdwcgvoglqhx9oojq` (`member_id`),
  KEY `FKivtgn9m3v8nycpkfgg28fpy8e` (`nft_id`),
  KEY `FK7l6c42813xwj4527jisf9k75d` (`photo_id`),
  CONSTRAINT `FK7l6c42813xwj4527jisf9k75d` FOREIGN KEY (`photo_id`) REFERENCES `photo` (`photo_id`),
  CONSTRAINT `FKivtgn9m3v8nycpkfgg28fpy8e` FOREIGN KEY (`nft_id`) REFERENCES `nft` (`nft_id`),
  CONSTRAINT `FKjdxqaj1hxder72fm9qjn8lyht` FOREIGN KEY (`drawing_file_id`) REFERENCES `drawing_file` (`drawing_file_id`),
  CONSTRAINT `FKn02g518xhdwcgvoglqhx9oojq` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drawing`
--

LOCK TABLES `drawing` WRITE;
/*!40000 ALTER TABLE `drawing` DISABLE KEYS */;
INSERT INTO `drawing` VALUES (1,'2023-08-13 11:13:24.374779','2023-08-16 14:57:39.927809','운이좋아','애벌래','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/dc5d190d-bb49-497d-85f9-11770f95fb68230813_111230.jpg',3,_binary '','애벌래',80,1,1,6,5),(2,'2023-08-13 11:16:19.322384','2023-08-16 16:43:24.217801','ㅎㅎㅎㅎ','못생긴 돼지 ','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/7bfed640-4039-4c5f-ab55-461b67d6990d230813_111522.jpg',0,_binary '','꿀꿀이',23,2,5,9,11),(3,'2023-08-13 11:16:33.413934','2023-08-14 12:46:24.459971','ㅎㅎㅎㅎ','못생긴 돼지 ','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/e279d4f8-a1a1-443b-8ecc-bc44e106ef74230813_111522.jpg',1,_binary '','꿀꿀이',35,3,5,1,11),(4,'2023-08-13 11:16:56.923497','2023-08-15 23:48:22.214403','ㅎㅎㅎㅎ','못생긴 돼지','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/61281c33-e6cf-4ec4-a100-60f55480434a230813_111522.jpg',1,_binary '','꿀꿀이',17,4,5,8,11),(5,'2023-08-13 11:16:58.273920','2023-08-16 14:39:07.385257','ㅎㅎㅎㅎ','못생긴 돼지','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/bc89dfbb-aff5-485d-ba0b-cff38a71b8d9230813_111522.jpg',1,_binary '','꿀꿀이',32,5,5,10,11),(6,'2023-08-13 11:17:43.215680','2023-08-16 15:20:36.404783','방울이','뿔이 있고 불을 뿜는다','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/099b95ca-33e6-45fd-91ed-2928dce8fcba230813_111559.jpg',4,_binary '','불 뿜는 용',110,6,2,2,11),(7,'2023-08-13 11:24:17.858765','2023-08-14 15:38:48.524412','물방울이','토코','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/d8ca5c19-fef3-4767-a926-644554f72bc9230813_112310.jpg',2,_binary '','얼룩강아지',38,7,8,4,25),(8,'2023-08-13 11:27:52.587977','2023-08-15 23:49:03.813339','운이좋아','♡♡','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/ecc5e09b-4db9-4961-91f0-e19e7a5a8ffe230813_112318.jpg',1,_binary '','핱하트무늬동물',36,8,1,3,25),(9,'2023-08-13 11:32:03.494229','2023-08-16 14:27:10.498685','돼지국밥','악어떼','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/5c092b45-8eae-4cc3-8bc1-e10c9e8ac82f230813_113152.jpg',1,_binary '','악어',28,9,6,5,37),(10,'2023-08-13 11:41:46.479769','2023-08-14 15:35:10.313154','예쁜이','강아지','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/44bc92ee-0ea5-420e-b616-68790497d860230813_114037.jpg',0,_binary '','강아지',14,10,6,7,25),(11,'2023-08-13 11:48:00.859233','2023-08-16 14:57:27.850831','꿀꿀이','ㄹㅇㄹㄹㄹㄹ, \nㅣㅡ\n','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/2b26d720-7bdc-4297-a7ce-f754d79781bb230813_114742.jpg',0,_binary '','오옹 ',15,11,5,12,1),(12,'2023-08-13 11:49:01.933061','2023-08-16 14:57:19.482146','꿀꿀이','ㅇ어아아아탙','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/2add50a6-9a95-4370-978d-5df58750f46f230813_114845.jpg',1,_binary '\0','악어',26,12,5,NULL,37),(13,'2023-08-13 11:50:54.657790','2023-08-16 10:02:26.601006','예쁜이','해가 떠써요','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/9b3e1549-535c-464a-957f-3ab7c315609e230813_114705.jpg',0,_binary '\0','해 ',25,13,6,NULL,38),(14,'2023-08-13 13:39:20.093341','2023-08-16 14:57:23.456029','나','cloud','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/52b64f60-78bc-40fa-b2d1-b46d0ec263ff230813_133904.jpg',1,_binary '','long',33,14,4,15,39),(15,'2023-08-13 13:40:03.463963','2023-08-16 10:02:28.368074','나','cloud','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/3cf65f0c-3fb1-4501-a3ee-a927b18ec788230813_133950.jpg',0,_binary '\0','longlong',74,15,4,NULL,40),(16,'2023-08-13 15:00:13.086295','2023-08-16 15:20:12.833028','나','nnn','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/6a82e7a9-a164-44c8-90a5-41cde182173d230813_150004.jpg',0,_binary '\0','nnn',219,16,4,NULL,54),(17,'2023-08-14 12:06:48.101100','2023-08-16 10:02:33.907018','나','hahah','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/0af01a69-b34a-4a02-be71-42cd44e803f4230814_030638.jpg',0,_binary '\0','hahah',17,17,4,NULL,67),(18,'2023-08-14 12:08:43.677280','2023-08-16 14:57:43.535104','나','????','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/bb4aaa43-c3dd-4bc5-b388-a63fee958f21230814_030834.jpg',0,_binary '\0','?????',17,18,4,NULL,59),(19,'2023-08-14 12:09:12.562476','2023-08-16 14:57:45.653180','나','aa','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/be3a8d9c-f161-47d0-8561-20be57c3bad3230814_030907.jpg',0,_binary '\0','gg',11,19,4,NULL,67),(20,'2023-08-14 12:13:09.752592','2023-08-16 14:39:33.046197','나','f','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/e1d17df5-f993-4dec-bb00-fa433ddd6695230814_031306.jpg',1,_binary '\0','f',73,20,4,NULL,68),(21,'2023-08-14 12:50:47.959373','2023-08-16 14:57:49.940657','羅?','치킨','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/e6459e2d-6644-409e-9e37-4ce3c5530e36230814_125013.jpg',0,_binary '\0','사살',43,21,4,NULL,72),(22,'2023-08-14 14:21:17.776375','2023-08-16 00:12:06.122711','이영준카카오','잇는','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/21d8da10-edfc-401d-8f72-9b1e9bbb0899230814_142107.jpg',0,_binary '\0','자신',12,22,4,NULL,72),(23,'2023-08-14 15:35:37.598963','2023-08-16 14:57:16.711522','이영준카카오','ㅎㅎ','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/e5421539-bacf-4db8-9403-97414d5c6cca230814_153528.jpg',0,_binary '\0','ㅎㅎ',8,23,4,NULL,73),(24,'2023-08-14 15:42:20.082256','2023-08-16 14:57:53.399972','이영준카카오','그그','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/443c6175-ae29-48ef-8f27-9761ef5ba74e230814_154204.jpg',1,_binary '\0','효',22,24,4,NULL,72),(25,'2023-08-14 15:51:28.430352','2023-08-16 09:00:12.635561','이영준카카오','꼬양이요','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/056a6c64-e7ea-4de1-ab80-7cf162843b3b230814_155106.jpg',1,_binary '\0','오옷',8,25,4,NULL,73),(26,'2023-08-14 16:57:23.640022','2023-08-16 16:43:20.283989','이영준카카오','fgfgfg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/81852ace-fc0b-4b94-835a-d1ea3f253d13230814_075712.jpg',0,_binary '\0','fgfg',13,26,4,NULL,74),(27,'2023-08-14 22:11:40.335999','2023-08-16 16:43:19.829989','이영준카카오','fgfgfg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/f6ec7029-c741-4c76-a63f-f499737d91ff230814_221133.jpg',0,_binary '\0','gfgfg',8,27,4,NULL,76),(28,'2023-08-14 22:15:06.982483','2023-08-16 16:43:19.226120','이영준카카오','rwasr','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/abac0865-26ca-489b-81a5-f8eaf25f8309230814_221455.jpg',0,_binary '\0','test',11,28,4,NULL,77),(29,'2023-08-15 15:34:59.208888','2023-08-16 16:43:18.710816','이영준카카오','짹짹','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/cc7dcdff-800e-43ab-85a4-c79a7251d391230815_153446.jpg',0,_binary '','병아리',23,29,4,16,11),(30,'2023-08-15 16:52:05.660302','2023-08-16 16:43:17.354133','뭉게뭉게도화지','새','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/0e06bedd-279d-4611-8afd-5122a1c30985230815_165159.jpg',0,_binary '','새',91,30,6,17,24),(31,'2023-08-16 13:53:02.713238','2023-08-16 16:43:54.898550','빨강이','제발~~~!','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/43b0aaea-4e46-4259-b14e-99369a17c391230816_045252.jpg',0,_binary '','출시하자	',20,31,3,18,106),(32,'2023-08-16 14:56:58.917229','2023-08-16 16:43:09.693795','shin','산 뒤에 숨숨','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/a189f0e2-2614-4bec-a08b-9759dfdb959f230816_145635.jpg',0,_binary '\0','숨숨',11,32,12,NULL,108);
/*!40000 ALTER TABLE `drawing` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-16 17:14:35
