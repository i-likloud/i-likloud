-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i9d101.p.ssafy.io    Database: backend
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `photo`
--

DROP TABLE IF EXISTS `photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `photo` (
  `photo_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `bookmark_cnt` int NOT NULL DEFAULT '0',
  `photo_url` varchar(255) NOT NULL,
  `pick_cnt` int NOT NULL DEFAULT '0',
  `member_id` bigint DEFAULT NULL,
  `photo_file_id` bigint DEFAULT NULL,
  PRIMARY KEY (`photo_id`),
  KEY `FK8oxuct7r7hyi4mf94bnebupr9` (`member_id`),
  KEY `FK3ve95ewdi2luj2n1oxxuyokd4` (`photo_file_id`),
  CONSTRAINT `FK3ve95ewdi2luj2n1oxxuyokd4` FOREIGN KEY (`photo_file_id`) REFERENCES `photo_file` (`photo_file_id`),
  CONSTRAINT `FK8oxuct7r7hyi4mf94bnebupr9` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photo`
--

LOCK TABLES `photo` WRITE;
/*!40000 ALTER TABLE `photo` DISABLE KEYS */;
INSERT INTO `photo` VALUES (2,'2023-08-12 20:02:15.807870','2023-08-12 20:02:15.807870',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/639bb130-51f8-4062-b2de-a0b5e3f29b254.jpg',0,1,2),(3,'2023-08-12 20:02:24.755623','2023-08-12 20:02:24.755623',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/10c2c6e3-87f4-4dc1-bf3f-a434d95e9b903.png',0,1,3),(4,'2023-08-12 20:02:33.073136','2023-08-12 20:02:33.073136',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/626fa0aa-988a-4628-b362-6f3b9989680b2.png',0,1,4),(5,'2023-08-12 20:02:45.933476','2023-08-13 11:13:24.376024',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/b34955d5-8946-40d7-8ae6-cb76918a7b511.png',1,1,5),(6,'2023-08-12 20:02:58.747192','2023-08-12 20:02:58.747192',2,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/52951a91-0e5e-4b5b-8bc2-9d1b8f99c7e520230710_193607 (1) - 송.jpg',0,1,6),(7,'2023-08-12 20:03:08.126568','2023-08-12 20:03:08.126568',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/701d1934-e17c-479b-95cc-dd7725d1fc5520230608_194349 - 송.jpg',0,1,7),(8,'2023-08-12 20:03:21.198767','2023-08-12 20:03:21.198767',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/157ead7f-2be1-4284-964c-f9dd0c23749720210812_191443 - 황신운.jpg',0,1,8),(9,'2023-08-12 20:03:31.824145','2023-08-12 20:03:31.824145',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/9bd1bf15-d559-4bbe-8012-752194cfadbc20180824_205218 - 황신운.jpg',0,1,9),(10,'2023-08-12 20:03:40.706704','2023-08-12 20:03:40.706704',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/ed07d2d3-b835-44ee-8805-61b81949503d14.jpeg',0,1,10),(11,'2023-08-12 20:03:48.197508','2023-08-15 15:34:59.215921',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/653ae675-f3bf-412b-a554-9e90de36d63b13.jpeg',6,1,11),(12,'2023-08-12 20:03:56.192987','2023-08-12 20:03:56.192987',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/e6bbc24f-487e-4a0b-8ba3-2d076b294a8912.jpeg',0,1,12),(13,'2023-08-12 20:04:02.708766','2023-08-12 20:04:02.708766',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/571b06c6-6e03-45a7-b52d-f8187fc48c4411.jpeg',0,1,13),(14,'2023-08-12 20:04:10.898951','2023-08-12 20:04:10.898951',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/3349d76b-9e70-4b28-91ff-f29ff70be51010.jpeg',0,1,14),(15,'2023-08-12 20:04:17.683174','2023-08-13 08:15:04.222257',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/2adf72b6-4d76-495b-90bb-e4cdf2cc9e039.jpeg',1,1,15),(16,'2023-08-12 20:04:24.731853','2023-08-12 20:04:24.731853',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/33d61099-8e9f-4e49-81d3-23ca5719b88b8.jpeg',0,1,16),(17,'2023-08-12 20:04:31.595632','2023-08-12 20:04:31.595632',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/bea79bb2-0006-405c-8457-0b153286edd37.jpeg',0,1,17),(18,'2023-08-12 20:04:42.513429','2023-08-12 20:04:42.513429',1,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/e46dd90a-0285-4f99-9427-67b1e88b5d5d6.jpg',0,1,18),(19,'2023-08-12 20:04:54.752170','2023-08-12 20:04:54.752170',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/36f753cd-a220-4289-9a1b-e2c73795a122고래구름 - 황하음.jpg',0,1,19),(20,'2023-08-12 20:05:53.132333','2023-08-12 20:05:53.132333',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/ba00ef5d-64d1-430b-a7be-477f49ef240a1690527536960 - 황신운.jpg',0,1,20),(21,'2023-08-12 20:06:04.506616','2023-08-12 20:06:04.506616',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/a7f947f4-3f62-4d75-b7aa-af3f485d65531690527536872 - 황신운.jpg',0,1,21),(22,'2023-08-12 20:06:11.762609','2023-08-12 20:06:11.762609',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/e3f3f897-5122-4112-8152-57e185582cb01690527536767 - 황신운.jpg',0,1,22),(23,'2023-08-12 20:06:24.987415','2023-08-12 20:06:24.987415',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/efafb59e-5966-4826-9fdc-945573447c6d1690527535094 - 황신운.jpg',0,1,23),(24,'2023-08-12 20:06:40.525627','2023-08-15 16:52:05.662346',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/b0193e81-5a3d-4797-8fe5-00ffa80b9cdb1690527535032 - 황신운.jpg',2,1,24),(25,'2023-08-12 20:06:57.829185','2023-08-13 11:41:46.481085',2,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/f593c1b4-8536-4766-beba-3d46240a521020230729_193536 - 들찌.jpg',5,1,25),(26,'2023-08-12 20:07:06.702685','2023-08-12 20:07:06.702685',1,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/f1fb977b-5e02-4611-bf1c-230c683cefda20230712_184640 - 송.jpg',0,1,26),(27,'2023-08-12 20:07:18.969054','2023-08-12 20:07:18.969054',2,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/fdb0a01b-a41b-4011-b4a0-8256b6e89a92KakaoTalk_20230729_121051486_03 - GumiInsider.jpg',0,1,27),(28,'2023-08-12 20:07:31.745699','2023-08-12 20:07:31.745699',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/4bdccb8a-367a-4c9f-b9d2-dd9f040c6266KakaoTalk_20230729_121051486_02 - GumiInsider.jpg',0,1,28),(29,'2023-08-12 20:07:43.862950','2023-08-12 20:07:43.862950',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/89fe88ef-562d-4f69-aa20-e7c889162cddIMG_7093 - yeonj u.jpeg',0,1,29),(30,'2023-08-12 20:07:53.182274','2023-08-12 20:07:53.182274',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/8a9b486c-9126-438d-984e-d58b4fa37a85IMG_6425 - 윤우혁.JPG',0,1,30),(31,'2023-08-12 20:08:01.341511','2023-08-12 20:08:01.341511',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/14740a5e-e3c2-43da-a923-b833655cb078총든오리구름 - 황하음.jpg',0,1,31),(32,'2023-08-12 20:08:11.147923','2023-08-12 20:08:11.147923',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/693878ad-3135-4c0a-ac11-255ac62f2220존잘구름 - 박현종.jpg',0,1,32),(33,'2023-08-12 20:08:21.995420','2023-08-13 07:37:17.011306',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/04c7f91e-a2ae-4a4a-b6b0-10b887a4ea7a악어 구름 - gol_ddae_rin_danbi.jpg',1,1,33),(34,'2023-08-12 20:08:29.572362','2023-08-13 07:56:50.578733',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/a01d9df5-01cf-4702-bbe9-d36d6691ca9c신기한 굴 - gol_ddae_rin_danbi.jpg',1,1,34),(35,'2023-08-12 20:08:45.890987','2023-08-13 08:00:07.051175',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/d094b809-77f0-496a-b0fa-d31556cc71bf뭉게구름 - gol_ddae_rin_danbi.jpg',2,1,35),(36,'2023-08-13 07:52:50.968166','2023-08-13 07:52:50.968166',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/f7634cad-c7c6-4faf-a68c-f79af1265d8f다운로드.jpeg.jpg',0,8,37),(38,'2023-08-13 11:45:42.436972','2023-08-13 11:50:54.659044',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/027ea60a-c0c5-48ba-8c94-5a5e9a2a73ea230813_114537.jpg',1,6,42),(39,'2023-08-13 13:38:58.132129','2023-08-13 13:39:20.094581',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/15bb1d5e-ae7c-4275-9119-a2b054cefdd9altostratus.jpg',1,4,43),(54,'2023-08-13 14:59:43.415060','2023-08-13 15:00:13.087663',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/02080383-485d-4dbd-91f2-6ff56d6153e2230813_145740.jpg',1,4,58),(56,'2023-08-13 15:32:04.566525','2023-08-13 15:32:04.566525',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/71206cd1-ecfc-4cf1-96d9-a21c530fcd43230813_145454.jpg',0,4,60),(57,'2023-08-13 15:32:23.616568','2023-08-13 15:32:23.616568',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/60d88b60-2e02-4744-bd42-89dd0ff551fa230810_163133.jpg',0,4,61),(62,'2023-08-13 15:41:33.528304','2023-08-13 15:41:33.528304',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/0feb75d5-2fcc-4a9f-b686-4494f1ba03eb230813_145454.jpg',0,4,66),(73,'2023-08-14 15:34:46.518603','2023-08-14 15:51:28.431697',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/20c6d7bf-e5d9-4919-8ca5-b655f8df03d6engin-akyurt-gJILnne_HFg-unsplash.jpg',2,6,79),(74,'2023-08-14 16:56:56.618181','2023-08-14 16:57:23.641158',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/a97ca586-4a3f-4234-a16c-75b44c6a0713230809_072339.jpg',1,4,80),(76,'2023-08-14 22:11:28.848517','2023-08-14 22:11:40.337443',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/d91a5c26-b32a-4045-a3af-77c304d27e87download.jpeg',1,4,82),(106,'2023-08-15 15:14:55.445004','2023-08-16 13:53:02.715366',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/28973da5-7778-4a95-9297-f9cfe46e65fb1000000231.jpg',1,4,122),(108,'2023-08-16 14:55:15.065748','2023-08-16 14:56:58.919055',0,'https://i-likloud.s3.ap-northeast-2.amazonaws.com/photo/f10c4679-5243-4633-b7a1-b8ac11f8f75720230725_214711.jpg',1,12,127);
/*!40000 ALTER TABLE `photo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-16 17:14:36
