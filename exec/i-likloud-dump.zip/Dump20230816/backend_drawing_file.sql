-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i9d101.p.ssafy.io    Database: backend
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `drawing_file`
--

DROP TABLE IF EXISTS `drawing_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drawing_file` (
  `drawing_file_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`drawing_file_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drawing_file`
--

LOCK TABLES `drawing_file` WRITE;
/*!40000 ALTER TABLE `drawing_file` DISABLE KEYS */;
INSERT INTO `drawing_file` VALUES (1,'2023-08-13 11:13:24.372603','2023-08-13 11:13:24.372603','애벌래','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/dc5d190d-bb49-497d-85f9-11770f95fb68230813_111230.jpg'),(2,'2023-08-13 11:16:19.320863','2023-08-13 11:16:19.320863','꿀꿀이','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/7bfed640-4039-4c5f-ab55-461b67d6990d230813_111522.jpg'),(3,'2023-08-13 11:16:33.412656','2023-08-13 11:16:33.412656','꿀꿀이','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/e279d4f8-a1a1-443b-8ecc-bc44e106ef74230813_111522.jpg'),(4,'2023-08-13 11:16:56.922073','2023-08-13 11:16:56.922073','꿀꿀이','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/61281c33-e6cf-4ec4-a100-60f55480434a230813_111522.jpg'),(5,'2023-08-13 11:16:58.272535','2023-08-13 11:16:58.272535','꿀꿀이','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/bc89dfbb-aff5-485d-ba0b-cff38a71b8d9230813_111522.jpg'),(6,'2023-08-13 11:17:43.213886','2023-08-13 11:17:43.213886','불 뿜는 용','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/099b95ca-33e6-45fd-91ed-2928dce8fcba230813_111559.jpg'),(7,'2023-08-13 11:24:17.857324','2023-08-13 11:24:17.857324','얼룩강아지','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/d8ca5c19-fef3-4767-a926-644554f72bc9230813_112310.jpg'),(8,'2023-08-13 11:27:52.586543','2023-08-13 11:27:52.586543','핱하트무늬동물','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/ecc5e09b-4db9-4961-91f0-e19e7a5a8ffe230813_112318.jpg'),(9,'2023-08-13 11:32:03.492818','2023-08-13 11:32:03.492818','악어','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/5c092b45-8eae-4cc3-8bc1-e10c9e8ac82f230813_113152.jpg'),(10,'2023-08-13 11:41:46.478378','2023-08-13 11:41:46.478378','강아지','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/44bc92ee-0ea5-420e-b616-68790497d860230813_114037.jpg'),(11,'2023-08-13 11:48:00.857948','2023-08-13 11:48:00.857948','오옹 ','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/2b26d720-7bdc-4297-a7ce-f754d79781bb230813_114742.jpg'),(12,'2023-08-13 11:49:01.931492','2023-08-13 11:49:01.931492','악어','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/2add50a6-9a95-4370-978d-5df58750f46f230813_114845.jpg'),(13,'2023-08-13 11:50:54.656426','2023-08-13 11:50:54.656426','해 ','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/9b3e1549-535c-464a-957f-3ab7c315609e230813_114705.jpg'),(14,'2023-08-13 13:39:20.092037','2023-08-13 13:39:20.092037','long','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/52b64f60-78bc-40fa-b2d1-b46d0ec263ff230813_133904.jpg'),(15,'2023-08-13 13:40:03.462636','2023-08-13 13:40:03.462636','longlong','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/3cf65f0c-3fb1-4501-a3ee-a927b18ec788230813_133950.jpg'),(16,'2023-08-13 15:00:13.084934','2023-08-13 15:00:13.084934','nnn','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/6a82e7a9-a164-44c8-90a5-41cde182173d230813_150004.jpg'),(17,'2023-08-14 12:06:48.098060','2023-08-14 12:06:48.098060','hahah','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/0af01a69-b34a-4a02-be71-42cd44e803f4230814_030638.jpg'),(18,'2023-08-14 12:08:43.675980','2023-08-14 12:08:43.675980','?????','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/bb4aaa43-c3dd-4bc5-b388-a63fee958f21230814_030834.jpg'),(19,'2023-08-14 12:09:12.560898','2023-08-14 12:09:12.560898','gg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/be3a8d9c-f161-47d0-8561-20be57c3bad3230814_030907.jpg'),(20,'2023-08-14 12:13:09.751251','2023-08-14 12:13:09.751251','f','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/e1d17df5-f993-4dec-bb00-fa433ddd6695230814_031306.jpg'),(21,'2023-08-14 12:50:47.957983','2023-08-14 12:50:47.957983','사살','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/e6459e2d-6644-409e-9e37-4ce3c5530e36230814_125013.jpg'),(22,'2023-08-14 14:21:17.774935','2023-08-14 14:21:17.774935','자신','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/21d8da10-edfc-401d-8f72-9b1e9bbb0899230814_142107.jpg'),(23,'2023-08-14 15:35:37.597824','2023-08-14 15:35:37.597824','ㅎㅎ','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/e5421539-bacf-4db8-9403-97414d5c6cca230814_153528.jpg'),(24,'2023-08-14 15:42:20.080556','2023-08-14 15:42:20.080556','효','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/443c6175-ae29-48ef-8f27-9761ef5ba74e230814_154204.jpg'),(25,'2023-08-14 15:51:28.428962','2023-08-14 15:51:28.428962','오옷','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/056a6c64-e7ea-4de1-ab80-7cf162843b3b230814_155106.jpg'),(26,'2023-08-14 16:57:23.638858','2023-08-14 16:57:23.638858','fgfg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/81852ace-fc0b-4b94-835a-d1ea3f253d13230814_075712.jpg'),(27,'2023-08-14 22:11:40.334231','2023-08-14 22:11:40.334231','gfgfg','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/f6ec7029-c741-4c76-a63f-f499737d91ff230814_221133.jpg'),(28,'2023-08-14 22:15:06.981164','2023-08-14 22:15:06.981164','test','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/abac0865-26ca-489b-81a5-f8eaf25f8309230814_221455.jpg'),(29,'2023-08-15 15:34:59.199143','2023-08-15 15:34:59.199143','병아리','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/cc7dcdff-800e-43ab-85a4-c79a7251d391230815_153446.jpg'),(30,'2023-08-15 16:52:05.658200','2023-08-15 16:52:05.658200','새','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/0e06bedd-279d-4611-8afd-5122a1c30985230815_165159.jpg'),(31,'2023-08-16 13:53:02.711161','2023-08-16 13:53:02.711161','출시하자	','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/43b0aaea-4e46-4259-b14e-99369a17c391230816_045252.jpg'),(32,'2023-08-16 14:56:58.915434','2023-08-16 14:56:58.915434','숨숨','https://i-likloud.s3.ap-northeast-2.amazonaws.com/drawing/a189f0e2-2614-4bec-a08b-9759dfdb959f230816_145635.jpg');
/*!40000 ALTER TABLE `drawing_file` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-16 17:14:37
